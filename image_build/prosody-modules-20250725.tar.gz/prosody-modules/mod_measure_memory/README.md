---
labels:
- Statistics
summary: Measure memory usage
---

Description
===========

This module measures memory usage and reports using Prosody 0.10 APIs
