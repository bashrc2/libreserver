package XMPP::TestUtils;

use strict;
use warnings;

1;
