-- this module is deprecated, log an error and load the superseding module instead
module:depends"smacks"

module:log("error", "mod_smacks_offline is deprecated! Just use mod_smacks!");