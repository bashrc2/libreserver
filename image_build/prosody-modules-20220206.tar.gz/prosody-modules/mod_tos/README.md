# mod_tos

A very drafty module to implement some kind of Terms of Service acceptance
tool.

Currently, this only works with clients implementing this very drafty
protocol. The result of the experiments will be an update to the
[ToS ProtoXEP](https://xmpp.org/extensions/inbox/tos.html), with the goal
of acceptance.
