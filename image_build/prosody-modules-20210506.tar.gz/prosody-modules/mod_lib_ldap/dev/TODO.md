  * Make groups optional
  * Make groups work with both posixGroup and groupOfNames
