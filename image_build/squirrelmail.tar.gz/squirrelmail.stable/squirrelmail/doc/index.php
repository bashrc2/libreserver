<?php

/**
 * index.php
 *
 * Redirects to the index.html file.
 *
 * @copyright 1999-2018 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: index.php 14749 2018-01-16 23:36:07Z pdontthink $
 * @package squirrelmail
 */

header('Location: index.html');

