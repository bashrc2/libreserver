---
labels:
- Stage-Alpha
rockspec:
  dependencies:
  - mod_sasl2
summary: "XEP-0386: Bind 2.0"
---

Experimental early implementation of [XEP-0386: Bind 2.0] for use with
[mod_sasl2].
