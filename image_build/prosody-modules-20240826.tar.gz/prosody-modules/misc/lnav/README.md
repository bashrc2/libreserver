% Prosody log format for lnav

This is a format definition that allows <https://lnav.org/> to better
handle Prosody logs.

Install it using `lnav -i ./prosody.json`
