---
labels:
- 'Stage-alpha'
summary: 'Enable ProtoXEP: Reminders support'
...


Introduction
============

`mod_reminders` implements ProtoXEP: Reminders.

Usage
=====

Place the sibling `mod_reminders.lua` somewhere under your
`plugins_path`.

