---
labels:
- Stage-Obsolete
superseded_by: mod_noofline_noerror
summary: Module obsolete, just use mod_smacks and mod_nooffline_noerror
...

::: {.alert .alert-warning}
This module was deleted and is superseded by [mod_smacks].
If you explicitly disabled mod_offline you need the new module
[mod_nooffline_noerror](https://modules.prosody.im/mod_nooffline_noerror.html) to regain all features of this module.
:::
