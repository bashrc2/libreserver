--[[
MIT License
Copyright © 2026 Maik Holme

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
]]

local jid = require "util.jid";
local st = require "util.stanza";

module:depends("muc");

local inform_admins = module:get_option_boolean("muc_moderated_chat_inform_admins", true)

local explain = "This room has moderated chat enabled. As a Moderator, you can use: \n```\n" ..
"!moderate\n```\nto switch the Room to moderated, and:\n```\n!unmoderate\n```\nto disable the moderation."

local MODERATED_CHAT_FIELD = "{xmpp:prosody.im}muc#roomconfig_moderated_chat";
local MODERATED_FIELD = "muc#roomconfig_moderatedroom";


local function command_enabled(room)
	local enabled = room._data.muc_moderated_chat_enabled == true;
	return enabled;
end

local function send_private_reply(room, occupant, text)
	local reply = st.message({
		type = "chat";
		from = room.jid;
		to = occupant.jid;
	}):tag("body"):text(text);

	room:route_to_occupant(occupant, reply);
end

local function send_message_to_admins(room, text)
	for _, occupant in room:each_occupant() do
		local affiliation = room:get_affiliation(occupant.bare_jid);

		if affiliation == "admin"
		or affiliation == "owner" then
			send_private_reply(room, occupant, text);
		end
	end
end

-- Mandatory things for ad-hoc room fields
local function handle_config_form(event)
	local room = event.room;

	table.insert(event.form, {
		name = MODERATED_CHAT_FIELD;
		type = "boolean";
		label = "Allow Admins to set a room to moderated.";
		desc = "Use a chat command: !moderate / !unmoderate to change the room moderation status.";
		value = command_enabled(room);
	});
end

-- Get the state of the module setting
local function handle_config_submit(event)
	local room = event.room;
	local new_value = event.value == true;

	if command_enabled(room) == new_value then
		return;
	end

	room._data.muc_moderated_chat_enabled = new_value;
	event.changed = true

	if new_value
	and inform_admins then
		send_message_to_admins(room,explain)
	end
end

-- Advertise the current value in MUC service discovery.
local function handle_disco_info(event)
	table.insert(event.form, {
		name = MODERATED_CHAT_FIELD;
		type = "boolean";
	});
	event.formdata[MODERATED_CHAT_FIELD] = command_enabled(event.room);
end

-- Inform admins when the MUC moderation setting is changed
local function handle_moderated_config_change(event)
	if not inform_admins then
		return;
	end

	local room = event.room;
	local new_value = event.value == true;

	if room:get_moderated() == new_value then
		return;
	end

	local status;
	if new_value then
		status = "The channel owner set the channel to moderated.";
	else
		status = "The channel owner set the channel to unmoderated.";
	end

	send_message_to_admins(room, status);
end

--main function for the command
local function handle_moderation_command(event)
	local room = event.room;
	local occupant = event.occupant;
	local stanza = event.stanza;
	if not room or not occupant or not command_enabled(room) then
		return;
	end

	local affiliation = room:get_affiliation(occupant.bare_jid);
	if affiliation ~= "admin"
	and affiliation ~= "owner" then
		return;
	end

	local nickname = jid.resource(occupant.nick);
	local body = stanza:get_child_text("body");

	local new_value;
	if body == "!moderate" or body == "!moderate " then
		new_value = true;
	else
		new_value = false;
	end

	local current_value = room:get_moderated();
	if current_value == new_value then
		local status = new_value
			and "The channel is already moderated."
			or "The channel is already unmoderated.";

		send_private_reply(room, occupant, status);

		return true;
	end

	room:set_moderated(new_value) --change room moderation status

	local status;
	if new_value then
		status = nickname .. " set the channel to moderated.";
	else
		status = nickname .. " set the channel to unmoderated.";
	end

	if inform_admins then
		send_message_to_admins(
			room,
			status
		);
	else
		send_private_reply(
			room,
			occupant,
			status
		);
	end

	-- Prevent the command from being delivered as a normal message.
	return true;
end

--inform admins of the command
local function handle_admin_info(event)
	local room = event.room;
	if not room
	or not command_enabled(room)
	or event.affiliation ~= "admin" then
		return;
	end

	local occupant = room:get_occupant_by_real_jid(event.jid);
	if not occupant then
		return;
	end

	send_private_reply(
		room,
		occupant,
		explain
	);
end

module:hook("muc-config-form", handle_config_form, 80-3.4); --after default moderation form
module:hook("muc-config-submitted/" .. MODERATED_CHAT_FIELD, handle_config_submit);
module:hook("muc-config-submitted/" .. MODERATED_FIELD, handle_moderated_config_change, 100);
module:hook("muc-disco#info", handle_disco_info);
module:hook("muc-set-affiliation", handle_admin_info);

module:hook("muc-occupant-groupchat", function(event)
	local stanza = event.stanza;
	if stanza.attr.type ~= "groupchat" then return; end

	local body = stanza:get_child_text("body");

	if body ~= "!moderate"
	and body ~= "!moderate "
	and body ~= "!unmoderate"
	and body ~= "!unmoderate " then
		return;
	end

	return handle_moderation_command(event);
end, 55);
