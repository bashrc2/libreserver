---
labels:
- 'Stage-Merged'
summary: Sync avatars between vCards and PEP
superseded_by: mod_vcard_legacy
---

::: {.alert .alert-info}
This module has been merged into Prosody since version 0.11,
see [mod_vcard_legacy][doc:modules:mod_vcard_legacy].
:::
