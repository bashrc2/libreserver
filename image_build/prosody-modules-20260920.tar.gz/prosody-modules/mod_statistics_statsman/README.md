---
labels:
- 'Stage-Obsolete'
summary: mod_statistics but based on the 0.10 statistics system
---

::: {.alert .alert-info}
This module doesn’t work since [5f15ab7c6ae5](https://hg.prosody.im/trunk/rev/5f15ab7c6ae5), or 0.12.
:::
