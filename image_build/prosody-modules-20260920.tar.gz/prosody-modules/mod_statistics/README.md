---
labels:
- Stage-Obsolete
- Statistics
summary: A rough 'prosodyctl mod_statistics top'
...

::: {.alert .alert-warning}
This module was an early protoype and is [not compatible with prosody anymore.](https://issues.prosody.im/647)

Use [the built-in statistics system](/doc/statistics) instead.
:::
