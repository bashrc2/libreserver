---
labels:
- 'Stage-Obsolete'
summary: Manually configure extended service discovery info
superseded_by: mod_server_info
...

Since Prosody 13.0, this module is [included in Prosody](https://prosody.im/doc/modules/mod_server_info), you will be redirected there shortly.
