---
labels:
- 'Stage-Obsolete'
- ArchiveStorage
summary: 'Storage module using mod\_muc\_log data with new stanza archive API'
superseded_by: mod_muc_mam
---

::: {.alert .alert-info}
This module hasn’t worked since 0.10, and its main feature is provided by
[mod_muc_mam][doc:modules:mod_muc_mam] since 0.11 anyway.
:::
