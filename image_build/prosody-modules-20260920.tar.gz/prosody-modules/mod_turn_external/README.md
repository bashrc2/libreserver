---
labels:
- 'Stage-Merged'
summary: Advertise an external TURN service
superseded_by: mod_turn_external
...

::: {.alert .alert-info}
This module has been merged into Prosody since version 0.12,
see [mod_turn_external][doc:modules:mod_turn_external].
:::
