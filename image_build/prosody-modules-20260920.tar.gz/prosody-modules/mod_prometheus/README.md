---
labels:
- Stage-Obsolete
- Statistics
summary: Implementation of the Prometheus protocol
superseded_by: mod_http_openmetrics
...

Introduction
============

::: {.alert .alert-error}
This module has been merged into Prosody as [mod_http_openmetrics][doc:modules:mod_http_openmetrics].
:::
