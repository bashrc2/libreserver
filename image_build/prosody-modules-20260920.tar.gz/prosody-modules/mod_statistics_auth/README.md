---
labels:
- 'Stage-Obsolete'
---

::: {.alert .alert-info}
This module doesn’t work with the statistics system introduced in Prosody 0.10.
:::
