---
labels:
- 'Stage-Merged'
summary: Log chatroom messages to disk
superseded_by: mod_muc_mam
...

::: {.alert .alert-info}
This module has been merged into Prosody since version 0.11,
see [mod_muc_mam][doc:modules:mod_muc_mam].
:::
