---
labels:
- 'Stage-Obsolete'
summary: Telnet command for showing TLS info
superseded_by: mod_admin_shell
---

The features provided by this module are now [included in
Prosody](https://prosody.im/doc/modules/mod_admin_shell), you will be
redirected there shortly.

`c2s:show()` and `s2s:show()` will describe the TLS status of each connection.
