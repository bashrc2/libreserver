<?php

////////////////////////////////////////////////////////////////////////////
// $Id: cleanup-config.php 13837 2009-09-04 14:04:47Z jervfors $
//
// Description: configuration file for statistics cleanup
//
////////////////////////////////////////////////////////////////////////////


// development options
$debug=100;


$prog="cleanup-guistats";
$adminemail="example@example.com";

// MySQL connection data
$sql_user   = "smstats";
$sql_pass   = "";
$sql_host   = "localhost";
$sql_db     = "smstats";

?>
