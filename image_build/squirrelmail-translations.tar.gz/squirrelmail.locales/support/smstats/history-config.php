<?php

////////////////////////////////////////////////////////////////////////////
// $Id: history-config.php 13837 2009-09-04 14:04:47Z jervfors $
//
// Description: configuration file for GUI messages history statistics
//
////////////////////////////////////////////////////////////////////////////


// the output directory
$outdir= "/home/www/smstats.topolis.inet/www";

// development options
$debug=100;


$prog="history-guistats";
$adminemail="example@example.com";

// MySQL connection data
$sql_user   = "smstats";
$sql_pass   = "";
$sql_host   = "localhost";
$sql_db     = "smstats";

?>
