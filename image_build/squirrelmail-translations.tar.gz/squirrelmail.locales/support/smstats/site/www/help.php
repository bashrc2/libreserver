<?php
require_once('header.php');

echo "<h2>Help information about SquirrelMail statistics</h2>\n";

echo "<p>under construction</p>";

?>

<table cellpadding="2" cellspacing="0" border="0" width="100%" bgcolor="#ececec">
<tr align="center"><td><font size="2">

<a href="./index.php">index</a> |
<a href="./about.php">about</a> |
help

</font></td></tr></table>
</td></tr></table>

<?php
require_once('footer.php');
?>