<?php
header( 'Content-Type: text/html; charset=iso-8859-1');
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n";
echo "<html>\n";
echo "<head>\n";
echo "<meta http-equiv=\"Content-Language\" content=\"en\">\n";
echo "<title>SquirrelMail i18n statistics</title>\n";
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"/includes/squirrelmail.css\">\n";
echo "</head>\n";
echo "<body>\n";
?>
